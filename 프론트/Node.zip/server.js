const express = require('express');
const cors = require('cors');
const multer = require('multer');

const storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb) {
        cb(null, file.originalname);
    },
});

const upload = multer({ storage: storage });

const app = express();

app.use(cors());

app.post('/image', upload.single('image'), function(req, res, next) {
    res.json({
        image: '분류 결과 : A업체',
        // 핵심은 여기. 
        // 서버에서 돌려주는 json의 key인 image와 프론트 Contact의
        // 2번째 '핵심'주석 부분에도 image가 있듯이, 서로 일치해야 함.
        
        // 어제 말씀드리려다 헷갈린 부분이 이것.
        // image로 통일되어있기 때문에, key값이 다른 것으로 바뀌면
        // 제대로 돌아오긴 하지만, 해당 json 데이터의 value값을 읽지 못함.

    });
});

app.listen(8000);
// 8000번 포트로 서버를 열고 있음.
